package com.farm.entities;

import java.time.LocalDateTime;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "TBL_FARMERSR")
public class FarmerSellRequest {

	@Id
	@GeneratedValue	
	private int sellRequestId;	
	private String cropType;	
	private String cropName;	
	private String fertilizerType;
	private int quantity;	
	private String soilPhCertificate;
	private int status;
	
	private LocalDateTime dateTime = LocalDateTime.now();

	
	private LocalDateTime endDateTime;

	private int sold = 0;
	private int duration;
	private double basePrice;	
	private double soldPrice = 0;
	

	@Transient
	private double maxBidAmount;

	@ManyToOne
	@JoinColumn(name = "farmerId", referencedColumnName ="farmerId", insertable =false, updatable = false )
	private FarmerDetails farmerDetails;

	@JsonIgnore
	@OneToMany(mappedBy = "bidderDetails", cascade = CascadeType.ALL)
	private Set<BiddingDetails> biddingDetails;

	public int getSold() {
		return sold;
	}

	public void setSold(int sold) {
		this.sold = sold;
	}

	public LocalDateTime getEndDateTime() {
		return endDateTime;
	}

	public void setEndDateTime(LocalDateTime endDateTime) {
		this.endDateTime = endDateTime;
	}

	public String getSoilPhCertificate() {
		return soilPhCertificate;
	}

	public void setSoilPhCertificate(String soilPhCertificate) {
		this.soilPhCertificate = soilPhCertificate;
	}

	public int getSellRequestId() {
		return sellRequestId;
	}

	public void setSellRequestId(int sellRequestId) {
		this.sellRequestId = sellRequestId;
	}

	public String getCropType() {
		return cropType;
	}

	public void setCropType(String cropType) {
		this.cropType = cropType;
	}

	public String getCropName() {
		return cropName;
	}

	public void setCropName(String cropName) {
		this.cropName = cropName;
	}

	public String getFertilizerType() {
		return fertilizerType;
	}

	public void setFertilizerType(String fertilizerType) {
		this.fertilizerType = fertilizerType;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public LocalDateTime getDateTime() {
		return dateTime;
	}

	public void setDateTime(LocalDateTime dateTime) {
		this.dateTime = dateTime;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public FarmerDetails getFarmerDetails() {
		return farmerDetails;
	}

	public void setFarmerDetails(FarmerDetails farmerDetails) {
		this.farmerDetails = farmerDetails;
	}

	public Set<BiddingDetails> getBiddingDetails() {
		return biddingDetails;
	}

	public void setBiddingDetails(Set<BiddingDetails> biddingDetails) {
		this.biddingDetails = biddingDetails;
	}

	public double getBasePrice() {
		return basePrice;
	}
	

	public double getSoldPrice() {
		return soldPrice;
	}

	public void setSoldPrice(double soldPrice) {
		this.soldPrice = soldPrice;
	}

	public void setBasePrice(double basePrice) {
		this.basePrice = basePrice;
	}

	public double getMaxBidAmount() {
		return maxBidAmount;
	}

	public void setMaxBidAmount(double maxBidAmount) {
		this.maxBidAmount = maxBidAmount;
	}

}
