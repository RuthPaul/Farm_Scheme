package com.farm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.farm.dao.Dao;
import com.farm.entities.BidderDetails;
import com.farm.entities.BiddingDetails;
import com.farm.entities.FarmerDetails;
import com.farm.entities.FarmerSellRequest;

@Service
public class BidderService {
	
	@Autowired
	private Dao dao;
	
	@Transactional
	public int addBidder(BidderDetails bidder) {
		dao.save(bidder);
		return bidder.getBidderId();
		
	}
	
	public List<BidderDetails> displayAllBidders() {
		return dao.fetchAll(BidderDetails.class);
	}
	@Transactional
	public List<FarmerSellRequest> currentBidDetails() {
		return dao.currentBidDetails();
	}
	
	@Transactional
	public int updateCurrentBid(BiddingDetails biddingDetails) {

		BiddingDetails bidDetails = (BiddingDetails) dao.save(biddingDetails);
		return bidDetails.getBiddingId();
	}

	@Transactional
	public List<FarmerSellRequest> fetchBidOverDetails() {
		return dao.fetchBidOverDetails();
	}
}
