package com.farm.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.farm.dao.Credential;

import com.farm.dao.Status;
import com.farm.entities.FarmerSellRequest;
import com.farm.service.FarmerService;
import com.farm.service.LoginService;

@Controller
public class LoginController {
	

	@Autowired
	private LoginService loginService;
	
	@Autowired
	private FarmerService farmerService;
	
	@RequestMapping("/login.lti")
	public ModelAndView loginValidation(@ModelAttribute("login") Credential credentials) {
		String obj = loginService.login(credentials.getEmail(), credentials.getPassword(), credentials.getRole());
		if(obj.equals("bidder_bidpage")) {
			List<FarmerSellRequest> farmerSellRequests = farmerService.displayRequest();
			 ModelAndView mv=new ModelAndView("bidder_bidpage","sellRequests", farmerSellRequests);
			 return mv;
		}else if(obj.equals("farmerpage")){
			 ModelAndView mv1=new ModelAndView("farmerpage");
			 return mv1;
		}else {
			 ModelAndView mv1=new ModelAndView("login");
			 return mv1;
		}
		
	}



}
