package com.farm.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "TBL_BIDDETAILS")
public class BiddingDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)	
	private int biddingId;

	
	private double bidAmount;

	@ManyToOne
	@JsonIgnore
	@JoinColumn(name = "bidderId",referencedColumnName ="bidderId", insertable =false, updatable = false)
	private BidderDetails bidderDetails;
	
	@ManyToOne
	@JoinColumn(name="sellRequestId",referencedColumnName ="sellRequestId", insertable =false, updatable = false)
	private FarmerSellRequest farmerSellRequest;

	public int getBiddingId() {
		return biddingId;
	}

	public void setBiddingId(int biddingId) {
		this.biddingId = biddingId;
	}

	public double getBidAmount() {
		return bidAmount;
	}

	public void setBidAmount(double bidAmount) {
		this.bidAmount = bidAmount;
	}

	public BidderDetails getBidderDetails() {
		return bidderDetails;
	}

	public void setBidderDetails(BidderDetails bidderDetails) {
		this.bidderDetails = bidderDetails;
	}

	public FarmerSellRequest getFarmerSellRequest() {
		return farmerSellRequest;
	}

	public void setFarmerSellRequest(FarmerSellRequest farmerSellRequest) {
		this.farmerSellRequest = farmerSellRequest;
	}

}
